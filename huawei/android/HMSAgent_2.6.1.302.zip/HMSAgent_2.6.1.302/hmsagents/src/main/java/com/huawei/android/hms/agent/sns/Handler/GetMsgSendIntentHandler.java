package com.huawei.android.hms.agent.sns.Handler;

import android.content.Intent;

import com.huawei.android.hms.agent.common.handler.ICallbackResult;

/**
 * 获取发送消息的intent回调
 */
public interface GetMsgSendIntentHandler extends ICallbackResult<Intent> {
}
