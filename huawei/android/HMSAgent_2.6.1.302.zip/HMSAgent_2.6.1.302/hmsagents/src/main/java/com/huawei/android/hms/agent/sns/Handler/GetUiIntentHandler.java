package com.huawei.android.hms.agent.sns.Handler;

import android.content.Intent;

import com.huawei.android.hms.agent.common.handler.ICallbackResult;

/**
 * 获取拉起社交界面的intent
 */
public interface GetUiIntentHandler extends ICallbackResult<Intent> {
}
